import React, { useState } from 'react';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import WasteClassifier from './components/WasteClassifier';
import About from './components/About';
import Footer from './components/Footer';

function App() {
  const [currentView, setCurrentView] = useState<'dashboard' | 'classifier' | 'about'>('dashboard');

  const renderCurrentView = () => {
    switch (currentView) {
      case 'classifier':
        return <WasteClassifier />;
      case 'about':
        return <About />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      <Header currentView={currentView} setCurrentView={setCurrentView} />
      <main className="container mx-auto px-4 py-8">
        {renderCurrentView()}
      </main>
      <Footer />
    </div>
  );
}

export default App;