import React, { useState, useRef } from 'react';
import { Upload, Camera, Brain, CheckCircle, AlertCircle, Loader } from 'lucide-react';

const WasteClassifier: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isClassifying, setIsClassifying] = useState(false);
  const [classificationResult, setClassificationResult] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const wasteCategories = [
    { name: 'Plastic', color: 'bg-blue-500', description: 'Bottles, containers, packaging' },
    { name: 'Paper', color: 'bg-green-500', description: 'Documents, cardboard, newspapers' },
    { name: 'Metal', color: 'bg-yellow-500', description: 'Cans, foil, metal containers' },
    { name: 'Glass', color: 'bg-purple-500', description: 'Bottles, jars, broken glass' },
    { name: 'Organic', color: 'bg-orange-500', description: 'Food waste, biodegradable items' },
    { name: 'Electronic', color: 'bg-red-500', description: 'Devices, batteries, cables' }
  ];

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string);
        setClassificationResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleClassify = async () => {
    if (!selectedImage) return;

    setIsClassifying(true);
    setClassificationResult(null);

    // Simulate transfer learning classification
    setTimeout(() => {
      const randomCategory = wasteCategories[Math.floor(Math.random() * wasteCategories.length)];
      const confidence = (85 + Math.random() * 10).toFixed(1);
      
      setClassificationResult({
        category: randomCategory.name,
        confidence: parseFloat(confidence),
        color: randomCategory.color,
        recommendations: getRecommendations(randomCategory.name),
        environmentalImpact: getEnvironmentalImpact(randomCategory.name)
      });
      
      setIsClassifying(false);
    }, 2000);
  };

  const getRecommendations = (category: string) => {
    const recommendations = {
      Plastic: ['Clean the container before recycling', 'Remove any labels if possible', 'Check local recycling guidelines'],
      Paper: ['Remove any plastic coating', 'Keep dry for better recycling', 'Bundle similar paper types together'],
      Metal: ['Rinse containers thoroughly', 'Remove any non-metal parts', 'Separate different metal types'],
      Glass: ['Handle carefully to avoid breakage', 'Remove caps and lids', 'Sort by color if required'],
      Organic: ['Compost if facilities available', 'Use for garden fertilizer', 'Avoid contamination with non-organic waste'],
      Electronic: ['Take to certified e-waste facility', 'Remove batteries separately', 'Consider donation if still functional']
    };
    return recommendations[category as keyof typeof recommendations] || [];
  };

  const getEnvironmentalImpact = (category: string) => {
    const impacts = {
      Plastic: { co2Saved: '2.3', energySaved: '15', description: 'Recycling plastic saves petroleum resources' },
      Paper: { co2Saved: '1.8', energySaved: '12', description: 'Recycled paper reduces deforestation' },
      Metal: { co2Saved: '4.2', energySaved: '28', description: 'Metal recycling uses 95% less energy than new production' },
      Glass: { co2Saved: '1.2', energySaved: '8', description: 'Glass can be recycled indefinitely without quality loss' },
      Organic: { co2Saved: '0.8', energySaved: '5', description: 'Composting reduces methane emissions from landfills' },
      Electronic: { co2Saved: '6.1', energySaved: '35', description: 'E-waste recycling recovers precious metals' }
    };
    return impacts[category as keyof typeof impacts] || { co2Saved: '1.0', energySaved: '10', description: 'Proper disposal helps the environment' };
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <div className="flex items-center justify-center space-x-2 mb-4">
          <Brain className="w-8 h-8 text-blue-600" />
          <h2 className="text-3xl font-bold text-gray-900">AI Waste Classifier</h2>
        </div>
        <p className="text-gray-600 text-lg">
          Upload an image and let our transfer learning model classify your waste item
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Upload Section */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Upload Waste Image</h3>
            
            {!selectedImage ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-all duration-200"
              >
                <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-2">Click to upload an image</p>
                <p className="text-sm text-gray-500">Supports JPG, PNG, WEBP (Max 10MB)</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="relative">
                  <img
                    src={selectedImage}
                    alt="Selected waste item"
                    className="w-full h-64 object-cover rounded-lg shadow-md"
                  />
                  <button
                    onClick={() => {
                      setSelectedImage(null);
                      setClassificationResult(null);
                    }}
                    className="absolute top-2 right-2 bg-red-500 text-white p-2 rounded-full hover:bg-red-600 transition-colors"
                  >
                    ×
                  </button>
                </div>
                
                <button
                  onClick={handleClassify}
                  disabled={isClassifying}
                  className="w-full bg-gradient-to-r from-blue-600 to-green-600 text-white py-3 px-6 rounded-lg font-medium hover:from-blue-700 hover:to-green-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                >
                  {isClassifying ? (
                    <>
                      <Loader className="w-5 h-5 animate-spin" />
                      <span>Classifying...</span>
                    </>
                  ) : (
                    <>
                      <Camera className="w-5 h-5" />
                      <span>Classify Waste</span>
                    </>
                  )}
                </button>
              </div>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
            />
          </div>

          {/* Waste Categories Reference */}
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Supported Categories</h3>
            <div className="grid grid-cols-2 gap-3">
              {wasteCategories.map((category, index) => (
                <div key={index} className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className={`w-4 h-4 rounded-full ${category.color}`}></div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{category.name}</p>
                    <p className="text-xs text-gray-500">{category.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Results Section */}
        <div className="space-y-6">
          {classificationResult ? (
            <>
              <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
                <div className="flex items-center space-x-2 mb-4">
                  <CheckCircle className="w-6 h-6 text-green-500" />
                  <h3 className="text-lg font-semibold text-gray-900">Classification Result</h3>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-6 h-6 rounded-full ${classificationResult.color}`}></div>
                      <div>
                        <p className="font-semibold text-gray-900">{classificationResult.category}</p>
                        <p className="text-sm text-gray-600">Waste Category</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-green-600">{classificationResult.confidence}%</p>
                      <p className="text-sm text-gray-600">Confidence</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-medium text-gray-900">Environmental Impact</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-blue-50 p-3 rounded-lg">
                        <p className="text-sm text-gray-600">CO₂ Saved</p>
                        <p className="text-lg font-bold text-blue-600">{classificationResult.environmentalImpact.co2Saved} kg</p>
                      </div>
                      <div className="bg-green-50 p-3 rounded-lg">
                        <p className="text-sm text-gray-600">Energy Saved</p>
                        <p className="text-lg font-bold text-green-600">{classificationResult.environmentalImpact.energySaved} kWh</p>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                      {classificationResult.environmentalImpact.description}
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
                <h4 className="font-medium text-gray-900 mb-3">Recycling Recommendations</h4>
                <ul className="space-y-2">
                  {classificationResult.recommendations.map((rec: string, index: number) => (
                    <li key={index} className="flex items-start space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-700">{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </>
          ) : (
            <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
              <div className="text-center py-8">
                <Brain className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Ready for Classification</h3>
                <p className="text-gray-600">Upload an image to see AI-powered waste classification in action</p>
                
                <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">Transfer Learning Technology</h4>
                  <p className="text-sm text-blue-700">
                    Our model uses pre-trained neural networks fine-tuned on waste classification data, 
                    achieving high accuracy with minimal training time.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default WasteClassifier;