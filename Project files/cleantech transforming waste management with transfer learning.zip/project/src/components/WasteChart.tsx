import React, { useState } from 'react';
import { BarChart3, TrendingUp } from 'lucide-react';

const WasteChart: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const wasteData = [
    { category: 'Plastic', amount: 35, color: 'bg-blue-500', percentage: 35 },
    { category: 'Paper', amount: 28, color: 'bg-green-500', percentage: 28 },
    { category: 'Metal', amount: 15, color: 'bg-yellow-500', percentage: 15 },
    { category: 'Glass', amount: 12, color: 'bg-purple-500', percentage: 12 },
    { category: 'Organic', amount: 10, color: 'bg-orange-500', percentage: 10 }
  ];

  const maxAmount = Math.max(...wasteData.map(item => item.amount));

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <BarChart3 className="w-5 h-5 text-gray-600" />
          <h3 className="text-lg font-semibold text-gray-900">Waste Classification Distribution</h3>
        </div>
        <div className="flex items-center space-x-1 text-sm text-green-600">
          <TrendingUp className="w-4 h-4" />
          <span>Real-time data</span>
        </div>
      </div>

      <div className="space-y-4">
        {wasteData.map((item, index) => (
          <div
            key={index}
            className="group cursor-pointer"
            onMouseEnter={() => setActiveCategory(item.category)}
            onMouseLeave={() => setActiveCategory(null)}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">{item.category}</span>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">{item.amount}%</span>
                <span className="text-xs text-gray-400">({item.amount * 100} items)</span>
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3 relative overflow-hidden">
              <div
                className={`${item.color} h-3 rounded-full transition-all duration-500 ease-out ${
                  activeCategory === item.category ? 'shadow-lg' : ''
                }`}
                style={{
                  width: `${item.percentage}%`,
                  transform: activeCategory === item.category ? 'scaleY(1.2)' : 'scaleY(1)'
                }}
              />
              {activeCategory === item.category && (
                <div className="absolute inset-0 bg-white bg-opacity-20 rounded-full animate-pulse" />
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-600">Transfer Learning Accuracy</p>
            <p className="text-lg font-bold text-green-600">94.7%</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-600">Model Confidence</p>
            <p className="text-lg font-bold text-blue-600">97.2%</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WasteChart;