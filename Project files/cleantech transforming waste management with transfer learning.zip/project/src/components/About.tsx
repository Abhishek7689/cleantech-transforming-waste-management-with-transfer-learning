import React from 'react';
import { Brain, Recycle, Target, Users, Award, TrendingUp } from 'lucide-react';

const About: React.FC = () => {
  const features = [
    {
      icon: Brain,
      title: 'Transfer Learning',
      description: 'Advanced AI models pre-trained on millions of images, fine-tuned for waste classification with exceptional accuracy.'
    },
    {
      icon: Recycle,
      title: 'Smart Sorting',
      description: 'Automated waste categorization helping facilities process materials more efficiently and reduce contamination.'
    },
    {
      icon: Target,
      title: 'High Accuracy',
      description: '94.7% classification accuracy with continuous learning and model improvement based on real-world data.'
    },
    {
      icon: TrendingUp,
      title: 'Real-time Analytics',
      description: 'Comprehensive dashboards providing insights into waste patterns, recycling rates, and environmental impact.'
    }
  ];

  const stats = [
    { number: '5.2M+', label: 'Items Classified', color: 'text-blue-600' },
    { number: '94.7%', label: 'Accuracy Rate', color: 'text-green-600' },
    { number: '15+', label: 'Waste Categories', color: 'text-purple-600' },
    { number: '2,156kg', label: 'CO₂ Saved', color: 'text-emerald-600' }
  ];

  const team = [
    { name: 'AI Development', description: 'Deep learning and computer vision expertise' },
    { name: 'Environmental Science', description: 'Waste management and sustainability research' },
    { name: 'Software Engineering', description: 'Scalable system architecture and deployment' },
    { name: 'Data Science', description: 'Analytics, insights, and continuous improvement' }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-12">
      {/* Hero Section */}
      <div className="text-center">
        <div className="flex items-center justify-center space-x-2 mb-6">
          <div className="bg-gradient-to-r from-green-500 to-blue-500 p-3 rounded-xl">
            <Recycle className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
            CleanTech: Transforming Waste Management
          </h1>
        </div>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
          Revolutionizing waste management through cutting-edge transfer learning technology. 
          Our AI-powered solution makes waste classification faster, more accurate, and environmentally impactful.
        </p>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-xl shadow-lg p-6 text-center border border-gray-100 hover:shadow-xl transition-all duration-300">
            <div className={`text-3xl font-bold ${stat.color} mb-2`}>
              {stat.number}
            </div>
            <div className="text-gray-600 text-sm font-medium">
              {stat.label}
            </div>
          </div>
        ))}
      </div>

      {/* Features Section */}
      <div>
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
          Cutting-Edge Technology Features
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg p-8 border border-gray-100 hover:shadow-xl transition-all duration-300 hover:scale-105">
              <div className="flex items-center space-x-4 mb-4">
                <div className="bg-gradient-to-r from-blue-500 to-green-500 p-3 rounded-xl">
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">{feature.title}</h3>
              </div>
              <p className="text-gray-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* How It Works Section */}
      <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-8">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">How Transfer Learning Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="bg-white p-6 rounded-xl shadow-md mb-4">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-blue-600">1</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Pre-trained Model</h3>
              <p className="text-sm text-gray-600">Start with a model trained on millions of general images</p>
            </div>
          </div>
          <div className="text-center">
            <div className="bg-white p-6 rounded-xl shadow-md mb-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-green-600">2</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Fine-tuning</h3>
              <p className="text-sm text-gray-600">Adapt the model specifically for waste classification tasks</p>
            </div>
          </div>
          <div className="text-center">
            <div className="bg-white p-6 rounded-xl shadow-md mb-4">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-purple-600">3</span>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Deployment</h3>
              <p className="text-sm text-gray-600">Achieve high accuracy with minimal training time and data</p>
            </div>
          </div>
        </div>
      </div>

      {/* Project Team */}
      <div>
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">Project Expertise</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {team.map((member, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg p-6 text-center border border-gray-100 hover:shadow-xl transition-all duration-300">
              <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-blue-400 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">{member.name}</h3>
              <p className="text-sm text-gray-600">{member.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* SmartInternz Recognition */}
      <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-white text-center">
        <div className="flex items-center justify-center space-x-2 mb-4">
          <Award className="w-8 h-8" />
          <h2 className="text-2xl font-bold">SmartInternz Project</h2>
        </div>
        <p className="text-blue-100 text-lg mb-4">
          Developed as part of the SmartInternz program, showcasing innovative AI applications in environmental sustainability
        </p>
        <div className="flex items-center justify-center space-x-8 text-sm">
          <div>
            <div className="font-bold text-lg">AI/ML Focus</div>
            <div className="text-blue-100">Transfer Learning</div>
          </div>
          <div>
            <div className="font-bold text-lg">Impact Area</div>
            <div className="text-blue-100">Environmental Sustainability</div>
          </div>
          <div>
            <div className="font-bold text-lg">Technology</div>
            <div className="text-blue-100">Computer Vision</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;