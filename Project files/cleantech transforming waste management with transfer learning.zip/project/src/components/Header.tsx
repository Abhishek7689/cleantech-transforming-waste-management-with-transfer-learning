import React from 'react';
import { Recycle, BarChart3, Camera, Info } from 'lucide-react';

interface HeaderProps {
  currentView: 'dashboard' | 'classifier' | 'about';
  setCurrentView: (view: 'dashboard' | 'classifier' | 'about') => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, setCurrentView }) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'classifier', label: 'AI Classifier', icon: Camera },
    { id: 'about', label: 'About', icon: Info },
  ] as const;

  return (
    <header className="bg-white shadow-lg border-b-2 border-green-100">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-r from-green-500 to-blue-500 p-2 rounded-xl">
              <Recycle className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                CleanTech
              </h1>
              <p className="text-sm text-gray-600">Transforming Waste Management</p>
            </div>
          </div>
          
          <nav className="hidden md:flex space-x-1">
            {navItems.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setCurrentView(id)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                  currentView === id
                    ? 'bg-gradient-to-r from-green-500 to-blue-500 text-white shadow-lg'
                    : 'text-gray-600 hover:bg-gray-100 hover:text-green-600'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{label}</span>
              </button>
            ))}
          </nav>
        </div>
        
        {/* Mobile Navigation */}
        <nav className="md:hidden mt-4 flex space-x-1">
          {navItems.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setCurrentView(id)}
              className={`flex-1 flex flex-col items-center space-y-1 py-2 px-1 rounded-lg font-medium transition-all duration-200 ${
                currentView === id
                  ? 'bg-gradient-to-r from-green-500 to-blue-500 text-white'
                  : 'text-gray-600 hover:bg-gray-100 hover:text-green-600'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-xs">{label}</span>
            </button>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default Header;