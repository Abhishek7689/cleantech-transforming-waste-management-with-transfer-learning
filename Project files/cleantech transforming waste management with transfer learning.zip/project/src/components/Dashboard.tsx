import React from 'react';
import StatsCard from './StatsCard';
import WasteChart from './WasteChart';
import RecentActivity from './RecentActivity';
import { Trash2, Recycle, TrendingUp, Leaf } from 'lucide-react';

const Dashboard: React.FC = () => {
  const stats = [
    {
      title: 'Total Waste Processed',
      value: '12,458',
      unit: 'kg',
      change: '+12%',
      changeType: 'positive' as const,
      icon: Trash2,
      color: 'blue'
    },
    {
      title: 'Items Recycled',
      value: '8,234',
      unit: 'items',
      change: '+18%',
      changeType: 'positive' as const,
      icon: Recycle,
      color: 'green'
    },
    {
      title: 'Classification Accuracy',
      value: '94.7',
      unit: '%',
      change: '+2.1%',
      changeType: 'positive' as const,
      icon: TrendingUp,
      color: 'purple'
    },
    {
      title: 'CO₂ Saved',
      value: '2,156',
      unit: 'kg',
      change: '+25%',
      changeType: 'positive' as const,
      icon: Leaf,
      color: 'emerald'
    }
  ];

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-2xl p-8 text-white">
        <h2 className="text-3xl font-bold mb-2">Welcome to CleanTech Dashboard</h2>
        <p className="text-green-100 text-lg">
          Transforming waste management through AI-powered transfer learning technology
        </p>
        <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold">24/7</div>
            <div className="text-sm text-green-100">Active Monitoring</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">15+</div>
            <div className="text-sm text-green-100">Waste Categories</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">99.2%</div>
            <div className="text-sm text-green-100">System Uptime</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">5.2M</div>
            <div className="text-sm text-green-100">Items Classified</div>
          </div>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <StatsCard key={index} {...stat} />
        ))}
      </div>

      {/* Charts and Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <WasteChart />
        </div>
        <div className="lg:col-span-1">
          <RecentActivity />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;