import React from 'react';
import { Activity, CheckCircle, AlertCircle, Clock } from 'lucide-react';

const RecentActivity: React.FC = () => {
  const activities = [
    {
      id: 1,
      type: 'classification',
      message: 'Plastic bottle classified successfully',
      time: '2 minutes ago',
      status: 'success',
      icon: CheckCircle,
      color: 'text-green-500'
    },
    {
      id: 2,
      type: 'processing',
      message: 'Batch processing of 150 items completed',
      time: '5 minutes ago',
      status: 'success',
      icon: CheckCircle,
      color: 'text-green-500'
    },
    {
      id: 3,
      type: 'alert',
      message: 'Low confidence detection on metal can',
      time: '8 minutes ago',
      status: 'warning',
      icon: AlertCircle,
      color: 'text-yellow-500'
    },
    {
      id: 4,
      type: 'classification',
      message: 'Paper waste sorted into recycling',
      time: '12 minutes ago',
      status: 'success',
      icon: CheckCircle,
      color: 'text-green-500'
    },
    {
      id: 5,
      type: 'processing',
      message: 'Model retrained with new data',
      time: '1 hour ago',
      status: 'info',
      icon: Clock,
      color: 'text-blue-500'
    }
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
      <div className="flex items-center space-x-2 mb-6">
        <Activity className="w-5 h-5 text-gray-600" />
        <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
      </div>

      <div className="space-y-4">
        {activities.map((activity) => {
          const IconComponent = activity.icon;
          return (
            <div
              key={activity.id}
              className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors duration-200"
            >
              <div className={`${activity.color} mt-0.5`}>
                <IconComponent className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-gray-900 font-medium">
                  {activity.message}
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  {activity.time}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-green-50 rounded-lg">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-900">System Status</p>
            <p className="text-xs text-gray-600">All systems operational</p>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-green-600 font-medium">Online</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecentActivity;