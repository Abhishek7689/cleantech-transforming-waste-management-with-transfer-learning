import React from 'react';
import { Heart, Github, Linkedin, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-gray-200 mt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">CleanTech</h3>
            <p className="text-gray-600 mb-4">
              Transforming waste management through AI-powered transfer learning technology. 
              Building a sustainable future with smart classification and recycling solutions.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-blue-600 transition-colors">
                <Github className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-600 transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-600 transition-colors">
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-md font-semibold text-gray-900 mb-4">Technology</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-blue-600 transition-colors">Transfer Learning</a></li>
              <li><a href="#" className="hover:text-blue-600 transition-colors">Computer Vision</a></li>
              <li><a href="#" className="hover:text-blue-600 transition-colors">AI Classification</a></li>
              <li><a href="#" className="hover:text-blue-600 transition-colors">Real-time Analytics</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-md font-semibold text-gray-900 mb-4">Impact</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-blue-600 transition-colors">Sustainability</a></li>
              <li><a href="#" className="hover:text-blue-600 transition-colors">Recycling</a></li>
              <li><a href="#" className="hover:text-blue-600 transition-colors">Waste Reduction</a></li>
              <li><a href="#" className="hover:text-blue-600 transition-colors">Environmental Care</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-200 pt-6 mt-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <p className="text-sm text-gray-600">
              © 2025 CleanTech - SmartInternz Project. All rights reserved.
            </p>
            <p className="text-sm text-gray-600 flex items-center mt-2 md:mt-0">
              Made with <Heart className="w-4 h-4 text-red-500 mx-1" /> for a cleaner future
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;